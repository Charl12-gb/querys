-- Active: 1710859505632@@127.0.0.1@5432@exo1_db@public
SELECT count(*) from users where age > 30;