-- Active: 1710859505632@@127.0.0.1@5432@exo1_db@public
SELECT * FROM products ORDER BY price DESC;